#define NUCLEO
#include "pin_shield_1.h"
  #define CD_PORT D9_PORT
  #define CD_PIN  D9_PIN
  #define CS_PORT D10_PORT
  #define CS_PIN  D10_PIN
  #define RESET_PORT D8_PORT
  #define RESET_PIN  D8_PIN
  #define SD_PORT D4_PORT
  #define SD_PIN  D4_PIN
  #define MOSI_PORT D11_PORT
  #define MOSI_PIN  D11_PIN
  #define SCK_PORT D13_PORT
  #define SCK_PIN  D13_PIN
  
  #define SPI_PORT MOSI_PORT

